#include "OutputManager.H"

#include <fstream>
#include "AMRIO.H"
#include "CH_assert.H"
#include "computeNorm.H"
#include "CoarseAverage.H"
#include "FunctionOperators.H"
#include "GridsManager.H"
#include "HierarchyDataOps.H"
#include "LevelDataOps.H"
#include "VariableManager.H"

#define PM_CLASSNAME OutputManager
#define PM_TEMPLATESTR

/// table of the default values.
//---------------------------------------------------------------------------
PM_DEF (       bool,                    restart,                  false);
PM_DEF (        int,                   numHiers,                      3);
PM_DEF (        int,                  hierRatio,                      2);
PM_DEF (Vector<int>,                errNormType,       Vector<int>(1,0));
PM_DEF (       Real,             orderTolerance,                    0.9);
PM_DEF (        int,           domainCornerMask,                      0);
PM_DEF (       bool,            showConvergence,                   true);
PM_DEF (       bool, useRichardsonExtrapolation,                  false);
PM_DEF (       bool, excludeErrorsOnFinerLevels,                  false);
PM_DEF (        int,       fineCalcAsExactRatio,                      0);
PM_DEF (       bool,             showLatexTable,                   true);
PM_DEF (       bool,     outputToProcessor0Only,                   true);
PM_DEF (     string,      truncationErrorMethod,                 "none");
PM_DEF (        int,    expectedTruncationOrder,                      4);
PM_DEF (       bool,               writeHdf5Err,                   true);
PM_DEF (       bool,               writeHdf5Sol,                   true);
PM_DEF (       bool,               flushHdf5Dir,                   true);
PM_DEF (     string,                hdf5DirRoot,                    ".");
PM_DEF (     string,               hdf5DirFinal,                "final");
PM_DEF (     string,             hdf5DirHistory,              "history");
PM_DEF (     string,             hdf5DirRestart,              "restart");
PM_DEF (        int,             floatPrecision,                      2);
PM_DEF (Vector<int>,           tableColumnWidth,     Vector<int>(3, 15));
PM_DEF (       bool,           writeTimeHistory,                  false);
//---------------------------------------------------------------------------
typedef ParameterDependency<string> PDP;
//---------- Existence::True
PM_DEFD(          int,     numSnapshotDigits,                6,
        PDP( PDP::ExistenceTrue, "writeTimeHistory"));
PM_DEFD(          int,    intervalCheckpoint,               -1,
        PDP( PDP::ExistenceTrue, "writeTimeHistory"));
PM_DEFD(          int,          intervalPlot,               -1,
        PDP( PDP::ExistenceTrue, "writeTimeHistory"));
PM_DEFD(         bool,    refineIntervalPlot,             true,
        PDP( PDP::ExistenceTrue, "writeTimeHistory"));
PM_DEFD(         string,    prefixCheckpoint,            "chk",
        PDP( PDP::ExistenceTrue, "writeTimeHistory"));
PM_DEFD(         string,          prefixPlot,            "plt",
        PDP( PDP::ExistenceTrue, "writeTimeHistory"));

///----------------------------------------------------------------------

typedef DisjointBoxLayout                          DBL;
typedef GridsManager                               GDM;
typedef HierarchyDataOps                           HOP;
typedef Variable                                   VAR;

OutputManager::OutputManager() : PMM(), m_defined(false)
{
  initializeParameters();
}


OutputManager::~OutputManager()
{
}

void OutputManager::initializeParameters(void)
{
  PM_INIT(restart);
  PM_INIT(numHiers);
  PM_INIT(hierRatio);
  PM_INIT(errNormType);
  PM_INIT(orderTolerance);
  PM_INIT(domainCornerMask);
  PM_INIT(showConvergence);
  PM_INIT(useRichardsonExtrapolation);
  PM_INIT(excludeErrorsOnFinerLevels);
  PM_INIT(fineCalcAsExactRatio);
  PM_INIT(showLatexTable);
  PM_INIT(outputToProcessor0Only);
  PM_INIT(truncationErrorMethod);
  PM_INIT(expectedTruncationOrder);
  PM_INIT(writeHdf5Err);
  PM_INIT(writeHdf5Sol);
  PM_INIT(flushHdf5Dir);
  PM_INIT(hdf5DirRoot);
  PM_INIT(hdf5DirFinal);
  PM_INIT(hdf5DirHistory);
  PM_INIT(hdf5DirRestart);
  PM_INIT(floatPrecision);
  PM_INIT(tableColumnWidth);
  PM_INIT(writeTimeHistory);
  PM_INIT(numSnapshotDigits);
  PM_INIT(intervalCheckpoint);
  PM_INIT(intervalPlot);
  PM_INIT(refineIntervalPlot);
  PM_INIT(prefixCheckpoint);
  PM_INIT(prefixPlot);
}

void OutputManager::updateDependentParameters()
{
  if ( !get(writeTimeHistory) )
    {
      erase(intervalCheckpoint);
      erase(intervalPlot);
      erase(refineIntervalPlot);
      erase(prefixCheckpoint);
      erase(prefixPlot);
    }
  if ( get(truncationErrorMethod)!=string("Taylor") )
    erase(expectedTruncationOrder);

  // since this routine might be called multiple times
  // relative changes should not be put here.
  // e.g.
  // increase numHiers by 1 if fineCalcAsExactRatio is positive
  if (!get(showConvergence))
    set(showLatexTable, false);

  m_useFineCalcAsExact = get(fineCalcAsExactRatio)>0;
  if (get(useRichardsonExtrapolation) && m_useFineCalcAsExact)
    {
      MayDay::Error("Richardson Extrapolation cannot be true if fine calculation is used as exact solution!");
    }
  m_exactSolnFuncAvail = !m_useFineCalcAsExact
                      && !get(useRichardsonExtrapolation);
  const std::string& truncStr = get(truncationErrorMethod);
  // exact solution must be available if truncation error calculation needs it, 
  if ( truncStr==string("Exact") && !m_exactSolnFuncAvail )
    MayDay::Error("truncationErrorMethod=true requires exact solutions!");

  if ( truncStr!=string("none") && truncStr!=string("Exact") && 
       truncStr!=string("Taylor") )
    MayDay::Error("Unknown truncationErrorMethod!");

  if ( truncStr==string("Taylor") &&
       get(numHiers)<get(expectedTruncationOrder)+1 )
    MayDay::Error("numHiers is not big enough for expectedTruncationOrder");
  if ( truncStr!=string("none") && get(domainCornerMask)>0 )
    MayDay::Error("domainCornerMask only works for solution error!");
}

void OutputManager::registerVariable
(const Variable& var, VVL *const sol, VVL *const err,
 const Vector<RefCountedPtr<VectorFunction> >& func,
 const bool periodicCorrection,
 const Real t0)
{
  // check consistency
  // at this point, the LevelData might not have been allocated
  //  so do not check numLevels.
  const int nHiers = get(numHiers);
  CH_assert(     sol->size()==err->size() );
  CH_assert(     sol->size()==nHiers      );
  CH_assert( m_sol.find(var)==m_sol.end() );
  CH_assert( m_err.find(var)==m_err.end() );

  // the first use case : exact solution is available
  if (m_exactSolnFuncAvail)
    {
      if (get(showConvergence))
        {
          // there are cases that we only want to run one hierarchy
          CH_assert( nHiers>=1             );
          for (int i=0; i<func.size(); i++)
            CH_assert( !func[i].isNull() );
        }
      m_numErrors = nHiers;
    }
  // the second use case : Richardson extrapolation
  //   all hierarchies have the same layouts
  // the third use case : a fine calculation as exact solution
  //   the finest hierarchy has only one level 
  else
    {
      CH_assert( nHiers>=3             );
      m_numErrors = nHiers-1;
    }

  m_sol[var] = sol;
  m_err[var] = err;
  const int nComps = var.get(Variable::numComps); 
  if (nComps!=func.size())
    {
      pout()<< " inconsistency detected for variable "
            << var.get(Variable::name) << ": func size="
            << func.size() << endl;      
      CH_assert(false);
    }

  // update m_exactFunc
  Vector<FUN>& varFunc = m_exactFunc[var];
  varFunc.resize(nComps);
  for (int i=0; i<nComps; i++)
    {
      // when examine truncation error,
      //  set the exact solution to the initial condition
      if (get(truncationErrorMethod)==string("Taylor"))
        varFunc[i] = FUN(new SpaceFunction(func[i],t0));
      else
        varFunc[i] = func[i];
    }
  m_errNorm[var].resize( get(errNormType).size() );
  for (int i=0; i<m_errNorm[var].size(); i++)
    m_errNorm[var][i].resize(m_numErrors);
  m_periodicCorrection[var] = periodicCorrection;
}


std::pair<int,std::string>
OutputManager::getStartingStepAndFilename
(const Variable& var, const int hier, const int checkStride) const
{
  std::pair<int, std::string> val(0, "");
  if (get(restart)==false)
    return val;
  const string hierStr = string("hier") + paddedStr(hier,1);
  const string hdf5Dir = get(hdf5DirRoot) + "/" 
        + get(hdf5DirHistory) + "/" + hierStr + "/";
  const string extStr(".hdf5");
  string varName = var.get(Variable::name) + string(".sol.");
  bool foundFile = true;
  while (foundFile)
    {
      const string stepStr = paddedStr(val.first, get(numSnapshotDigits),
                                       false, '0');
      const string hd5Filename = varName + stepStr + extStr;
      const string checkFilename = hdf5Dir+hd5Filename;
      std::ifstream testStream;
      testStream.open(checkFilename.c_str(), std::ifstream::in);
      if (testStream.good())
        {
          val.second = checkFilename;
          val.first += checkStride;
        }
      else
        {
          val.first -= checkStride;
          foundFile  = false;
        }
      testStream.close();
    }
  return val;
}


/// generate by the following mathematica commands:
/// Ar = Table[(1/r^(i - 1))^j, {i, 4}, {j, 4}]
/// InvA = Simplify[Inverse[Ar]]
/// The coefficients are the last row of InvA.
const Vector<Real> OutputManager::getTaylorTruncationCoefs
(const Real& r, const int& minNumHiers)
{
  const Real r2 = r*r;
  const Real r4 = r2*r2;
  const Real r6 = r4*r2;
  const Real r8 = r4*r4;
  const Real r12 = r8*r4;
  const Real rm12 = (r-1)*(r-1);
  Vector<Real> coefs(minNumHiers);
  if (coefs.size()==2)
    {
      coefs[0] = r/(r-1);
      coefs[1] = -r2/(r-1);
    }
  else if (coefs.size()==3)
    {
      coefs[0] = r2*r/(r+1)/rm12;
      coefs[1] = -r2*r2/rm12;
      coefs[2] = r4*r2/(r+1)/rm12;
    }
  else if (coefs.size()==4)
    {
      const Real rp1r = 1/(1+r);
      const Real rr2r = 1/(1+r+r2);
      const Real rm13r = 1/(r-1)/rm12;
      const Real tmp1 = rp1r*rm13r;
      const Real tmp2 = tmp1*rr2r;
      coefs[0] = r6*tmp2;
      coefs[1] = -r6*r*tmp1;
      coefs[2] = r8*r*tmp1;
      coefs[3] = -r12*tmp2;
    }
  else if (coefs.size()==5)
    {
      const Real rp1r  = 1/(1+r);
      const Real rp1r2 = rp1r*rp1r;
      const Real rr2r = 1/(1+r+r2);
      const Real rr4r = 1/(1+r+2*r2+r2*r+r4);
      const Real rm14r = 1/rm12/rm12;
      const Real tmp1 = rm14r*rp1r2*rr4r;
      const Real tmp2 = rm14r*rp1r*rr2r;
      const Real tmp3 = rm14r*rp1r2;
      coefs[0] = r6*r4*tmp1;
      coefs[1] = -r8*r2*r*tmp2;
      coefs[2] = r8*r4*r*tmp3;
      coefs[3] = -r8*r8*tmp2;
      coefs[4] = r12*r8*tmp1;
    }
  else
    MayDay::Error("invalid input!");
  return coefs;
}

void OutputManager::updateVariablePointers
(const Variable& var, VVL *const sol, VVL *const err)
{
  // updating a variable not registered is an error.
  CH_assert( m_sol.find(var)!=m_sol.end() );
  CH_assert( m_err.find(var)!=m_err.end() );
  // check consistency
  CH_assert( sol->size()==err->size()   );
  CH_assert( sol->size()==get(numHiers) );

  m_sol[var] = sol;
  m_err[var] = err;
}

void OutputManager::initialize(const RealVect& origin,
                               const Real& dx00,
                               int numCells00,
                               int numLevels,
                               int refRatio)
{
  if (m_sol.empty() || m_err.empty())
    MayDay::Error("registerVariable has to be called before this one!");

  m_origin     = origin;
  m_dx00       = dx00;
  m_numCells00 = numCells00;
  m_numLevels  = numLevels;
  m_refRatio   = refRatio;
  // setting the ref-ratio vectors
  m_refV       = Vector<int>(m_numLevels-1, m_refRatio);
  m_refL       = Vector<int>(m_numLevels, 1);
  for (int j=1; j<m_refL.size(); j++)
    m_refL[j]  = m_refRatio*m_refL[j-1];
  m_refH = Vector<int>(get(numHiers), 1);
  for (int j=1; j<m_refH.size(); j++)
    m_refH[j]  = get(hierRatio)*m_refH[j-1];
  m_defined    = true;
  if (get(flushHdf5Dir) && get(restart))
    {
      MayDay::Error("When restart is true, flushHdf5dir has to be false!");
    }
  else if (get(flushHdf5Dir))
    {
      const string hdf5Dir = get(hdf5DirRoot);
      const string rmdir = string("rm -rf ") + hdf5Dir + "; ";
      const string mkdir = string("mkdir -p ") + hdf5Dir;
      //      int feedback=0;
      if (procID()==0)
        system((rmdir+mkdir).c_str());
      //        feedback = system((rmdir+mkdir).c_str());
    }
}

int OutputManager::report(const Variable& var, ostream& os,
                          const Vector<Real>& time,
                          const Real intendedOrder,
                          const Real dt00)
{
  CH_assert(m_defined);
  CH_assert(m_sol.find(var)!=m_sol.end());
  
  if (!get(showConvergence))
    return 0;

  // compute the error and its norms
  for (int i=0; i<get(numHiers); i++)
    computeError(var, i, time[i]);

  // rewrite some errors by truncation error
  if (get(truncationErrorMethod)=="Taylor")
    for (int i=0; i<=get(numHiers)-get(expectedTruncationOrder); i++)
      computeTaylorTruncationError(var, i, time[i]);

  VVL& err = *(m_err[var]);
  const Real dx00n = 1.0/m_numCells00;
  Vector<Vector<Real> >& norms = m_errNorm[var];
  const Vector<Real> targetConvergeRate(norms.size(),
                                        intendedOrder*get(orderTolerance));
  int nFail = 0;

  for (int k=0; k<err[0][0]->nComp(); k++)
    {
      for (int j=0; j<norms.size(); j++)
      for (int i=0; i<m_numErrors; i++)
        {
          // only compute norm for the coarsest level if asked so.
          if (get(excludeErrorsOnFinerLevels))
            norms[j][i] = computeNorm(*err[i][0], NULL, 1, dx00n/m_refH[i],
                                      Interval(k,k), get(errNormType)[j]);
          else
            norms[j][i] = computeNorm(err[i], m_refV, dx00n/m_refH[i],
                                      Interval(k,k), get(errNormType)[j]);
          // This is usually for truncation error, should divided by dt.
          // if ( get(truncationErrorMethod) )
          //   norms[j][i] /= dt00/m_refH[i];
        }
      Vector<Vector<Real> > normCopy(norms.size());
      if (get(truncationErrorMethod)=="Taylor")
          for (int j=0; j<norms.size(); j++)
            {
              normCopy[j].resize(m_numErrors-get(expectedTruncationOrder)+1);
              //   pout() << "\ntruncating error vector size.\n";
              for (int i=0; i<normCopy[j].size(); i++)
                normCopy[j][i] = norms[j][i];
            }
      else
        normCopy = norms;
      if (get(showConvergence))
        {
          pout() << "\nConvergence Results for " << var.getComponentName(k)
                 << ":\n";
          nFail += outputConvergence(os, normCopy, m_numCells00,
                                     get(hierRatio), targetConvergeRate );
        }
      if (get(showLatexTable))
        os << outputLatexTable(normCopy, m_numCells00, get(hierRatio));
    }
  return nFail;
}


int OutputManager::report
(const Vector<Variable>& outVar,
 ostream& os,
 GridsManager& gdm,
 Vector<VVL>& solution, 
 Vector<VVL>& error,
 const Vector<Vector<FUN> >& exactFun,
 const Vector<bool>& periodicCorrections,
 const Vector<Real>& te,
 const int order)
{
  // register the variable to OutputManager, associate them with vlfa.
  for (int i=0; i<outVar.size(); i++)
    registerVariable(outVar[i], &(solution[i]), &(error[i]),
                     exactFun[i], periodicCorrections[i]);
  
  const int numLevels                = gdm.get(GDM::numLevels);
  const int refRatio                 = gdm.get(GDM::refRatio);
  const RealVect origin              = gdm.get(GDM::origin);
  const Real dx0                     = gdm.get(GDM::dx0);
  initialize(origin, dx0, gdm.get(GDM::numCells0)[0], numLevels, refRatio); 
  
  // output the table of results.
  // A failure has its convergence less than min(spaceOrder, timeOrder).
  int status = 0;
  for (int i=0; i<outVar.size(); i++)
    status += report(outVar[i], os, te, order);
  return status;
}


int OutputManager::report
(const Vector<Variable>& varsV,
 ostream& os,
 GridsManager& gdm,
 Vector<VVX>& solutionV, 
 Vector<VVX>& errorV,
 const Vector<Vector<FUN> >& exactFunV,
 const Vector<bool>& periodicCorrectionV,
 const Vector<Real>& te,
 const int intendedOrder)
{
  VariableManager<FArrayBox> vrm;
  const int numHiers  = solutionV[0].size();
  const int numLevels = solutionV[0][0].size();
  Vector<int> nLevelsVec(numHiers, numLevels);
  vrm.define(nLevelsVec, numHiers);
  const int nVar = varsV.size();
  Vector<Variable> varsErrV(nVar);
  for (int i=0; i<nVar; i++)
    {
      vrm.registerVariable(varsV[i]);
      const string errName = varsV[i].get(VAR::name)+"_Err";
      varsErrV[i] = Variable(errName.c_str(), 0,
                             varsV[i].get(VAR::numComps));
      vrm.registerVariable(varsErrV[i]);
    }
  
  // get the grids.
  Vector<Vector<DBL> > dblVH(numHiers);
  for (int i=0; i<numHiers; i++)
    {
      dblVH[i].resize(numLevels);
      for (int l=0; l<numLevels; l++)
        dblVH[i][l] = solutionV[0][i][l]->disjointBoxLayout();
    }

  /// duplicate pointers as shorthands for LFAs
  Vector<VVL> solV(nVar);
  Vector<VVL> errV(nVar);
  for (int i=0; i<nVar; i++)
    {
      solV[i].resize(numHiers);
      errV[i].resize(numHiers);
    }
  /// allocate the storage of variables for this hierarchy
  ///  and copy the pointers to solV and errV
  for (int i=0; i<nVar; i++)
    for (int h=0; h<numHiers; h++)
      {
        vrm.allocateStorage(varsV[i], dblVH[h], h);
        solV[i][h] = vrm.getHierarchy(varsV[i], h);
        HOP::convertFaceAvg2CellAvg(solutionV[i][h], solV[i][h]);
        vrm.allocateStorage(varsErrV[i], dblVH[h], h); 
        errV[i][h] = vrm.getHierarchy(varsErrV[i], h);
      }

  return report(varsV, os, gdm, solV, errV, exactFunV,
                periodicCorrectionV, te, intendedOrder);
}


void OutputManager::computeError
(const Variable& var, const int hier, Real time)
{
  const int nHs = get(numHiers);
  CH_assert(hier<nHs);
  // no error to compute on the finest hierarchy if it is used as exact
  if (hier==nHs-1 && !m_exactSolnFuncAvail)
    return;

  VVL& sol = *(m_sol[var]);
  VVL& err = *(m_err[var]);
  int nComp = sol[hier][0]->nComp();
  Real dx  = m_dx00/m_refH[hier];
  /// put `exact' solution to err first
  if (m_exactSolnFuncAvail)
    HOP::setToFuncVal(m_exactFunc[var], err[hier],
                      m_origin, m_refV, dx, time);
  else if ( m_useFineCalcAsExact )
    {
      // there is only one level in the finest hierarchy, hence 0
      const DBL& fineDBL = sol[nHs-1][0]->disjointBoxLayout();
      // start as the ratio to the coarsest level in this hierarchy.
      int ref = m_refL[m_numLevels-1]*m_refH[nHs-2]
               *get(fineCalcAsExactRatio)/m_refH[hier];
      for(int j=0; j<m_numLevels; j++)
        {
          CoarseAverage crseAvg(fineDBL, nComp, ref);
          crseAvg.averageToCoarse(*err[hier][j], *sol[nHs-1][0]);
          ref /= m_refRatio;
        }
    }
  // Richardson Extrapolation
  else
    {
      const int nLevels = get(excludeErrorsOnFinerLevels)? 1 : m_numLevels;
      HOP::setToZero(err[hier]);
      for(int j=0; j<nLevels; j++)
        {
          const DBL& crseDBL = sol[hier][j]->disjointBoxLayout();
          const DBL& fineDBL = sol[hier+1][j]->disjointBoxLayout();
          CoarseAverage averageOp(fineDBL, crseDBL, nComp, get(hierRatio));
          averageOp.averageToCoarse(*err[hier][j], *sol[hier+1][j]);
        }
    }

  // set sol to exact within corner masks
  // this shoud be done before periodic shift.
  const int cornerMask = get(domainCornerMask);
  IntVectSet levelCorners; 
  if (cornerMask>0)
    for (int j=0; j<m_numLevels; j++)
      {
        LevelData<FArrayBox>& lErr = *err[hier][j];
        const DBL& dbl = lErr.disjointBoxLayout();
        levelCorners.define_boxCorners(dbl.physDomain().domainBox());
        for(DataIterator dit = dbl.dataIterator(); dit.ok(); ++dit)
          {
            const Box& box = dbl[dit()];
            for (IVSIterator ivs(levelCorners); ivs.ok(); ++ivs)
              // if a level corner is inside this patch
              // set the corresponding region to zero.
              if (box.contains(ivs()))
                {
                  const Box crn = box & grow(Box(ivs(), ivs()), cornerMask-1);
                  // overwrite error so that the original solution
                  // can be recovered by another file.
                  lErr[dit()].copy((*sol[hier][j])[dit()], crn);
                  //  pout()<< "set error to zero in " << crn << std::endl;
                }
          }
      }

  // if (m_periodicCorrection[var])
  //  HOP::calibrateByConservation(sol[hier], err[hier]);
  //  HOP::checkData(err[hier]);
  
  // now compute err = sol - exact
  if (!get(excludeErrorsOnFinerLevels))
    {
      HOP::scale(err[hier], -1);
      HOP::incr(err[hier], sol[hier]);
    }
  else
    {
      LevelDataOps<FArrayBox> ldOp;
      ldOp.incr(*err[hier][0], *sol[hier][0], -1.0);
    }

  // possible shift for the pure periodic case or the pure Neumann case.
  if (m_periodicCorrection[var])
    HOP::enforceZeroSum(err[hier], m_refV, dx,
                        get(excludeErrorsOnFinerLevels));

  // make sure the errors are consistent with themselves.
  if (!get(excludeErrorsOnFinerLevels))
    HOP::enforceCFConsistency(err[hier], m_refV);
}


void OutputManager::computeTaylorTruncationError
(const Variable& var, const int hier, Real time)
{
  const Vector<Real> TaylorCoefs = getTaylorTruncationCoefs
    (get(hierRatio), get(expectedTruncationOrder));
  //  pout()<< " Taylor coefs: " << TaylorCoefs << endl;

  LevelDataOps<FArrayBox> ldOp;
  for(int j=0; j<m_numLevels; j++)
    {
      LevelData<FArrayBox>& errL = *((*m_err[var])[hier][j]);
      const DBL& crseDBL = errL.disjointBoxLayout();
      LevelData<FArrayBox> tmp(crseDBL, errL.nComp());
      ldOp.scale(errL, TaylorCoefs[0]);
      for (int h=1; h<get(expectedTruncationOrder); h++)
        {
          const LevelData<FArrayBox>& fineErr = *((*m_err[var])[hier+h][j]);
          const DBL& fineDBL = fineErr.disjointBoxLayout();
          const int r = m_refH[hier+h]/m_refH[hier];
          CoarseAverage averageOp(fineDBL, crseDBL, errL.nComp(), r);
          averageOp.averageToCoarse(tmp, fineErr);
          ldOp.incr(errL, tmp, TaylorCoefs[h]);
        }
    }  
}


void OutputManager::writeHDF5Final(const Vector<Real>& te, 
                                   const Vector<int>&  stepNumber,
                                   const Vector<Real>& dt)
{
  CH_assert(m_defined);
  for (int i=0; i<get(numHiers); i++)
    writeHDF5(i, stepNumber[i], m_dx00/m_refH[i], dt[i], te[i], true);
}

const std::string OutputManager::writeHDF5
(const int hier, const int step,
 const Real dx, const Real dt, const Real time,
 bool writeForFinal)
{
  CH_assert(m_defined);

  const string hierStr = string("hier") + paddedStr(hier,1); // + "_";
  const string hdf5Dir = get(hdf5DirRoot) + "/" 
    + (writeForFinal ? get(hdf5DirFinal) : get(hdf5DirHistory))
    +"/" +hierStr +"/";

  for (std::map<Variable, VVL*>::iterator
         mit=m_sol.begin(); mit!=m_sol.end(); mit++)
    {
      const Variable& var = mit->first;
      VVL& sol = *(m_sol[var]);
      VVL& err = *(m_err[var]);
      Vector<string> componentNames(var.get(Variable::numComps));
      for (int i=0; i<componentNames.size(); i++)
        componentNames[i] = var.getComponentName(i);

      // different hierarchy might have different numLevels.
      const int nLevels = sol[hier].size();
      Vector<DBL> dblV(nLevels);
      for (int i=0; i<dblV.size(); i++)
        dblV[i] = sol[hier][i]->disjointBoxLayout();
      const Box& box = dblV[0].physDomain().domainBox();
      const string stepStr = paddedStr(step, get(numSnapshotDigits), false, '0');
      const string extStr(".hdf5");
      const string extAni("visit");
      // system commands to deal with directories.
      const string rmdir = string("rm -rf ") + hdf5Dir + "; ";
      const string mkdir = string("mkdir -p ") + hdf5Dir;
      const string cmd = writeForFinal ? mkdir : rmdir+mkdir;
      // only one processor messes with dir at the first time step,
      //  otherwise the same dir be removed and made multiple times.
      // assume dumping results to processor 0
      if ( procID()==0 && (step==0 || writeForFinal) )
        {
          // rmdir should not be executed
          //  because multiple instances of OutputManager might cause problems.
          //          int feedback=0;
          //          feedback = system(mkdir.c_str());
          system(mkdir.c_str());
        }
      // write solution to hdf5 files
      if (get(writeHdf5Sol))
        {
          string varName = var.get(Variable::name) + string(".sol.");
          const string hd5Filename = varName + stepStr + extStr;
          WriteAMRHierarchyHDF5(hdf5Dir+hd5Filename, dblV, sol[hier],
                                componentNames, box, dx, dt, time,
                                m_refV, nLevels);
          if (procID()==0 && !writeForFinal)
            {
              const string fileAni = (hdf5Dir +"../" +hierStr +varName +extAni);
              ios_base::openmode mode = (step==0 ? ios_base::out
                                         : ios_base::app);
              ofstream animationList(fileAni.c_str(), mode);
              animationList << hierStr << "/" << hd5Filename << endl;
              animationList.close();
            }
        }
      // write error to hdf5 files
      // excluding intermediate steps when exactSolnFuncAvail is false
      // excluding the finest hierarchy when exactSolnFuncAvail is false
      bool writeErr = get(writeHdf5Err);
      if (!m_exactSolnFuncAvail)
        writeErr &= ( hier<get(numHiers)-1 && writeForFinal );
      if ( writeErr )
        {
          string varName = var.get(Variable::name) + string(".err.");
          computeError(var, hier, time);
          const string hd5Filename = varName + stepStr + extStr;
          WriteAMRHierarchyHDF5(hdf5Dir+hd5Filename, dblV, err[hier],
                                componentNames, box, dx, dt, time,
                                m_refV, nLevels);
          if (procID()==0 && !writeForFinal)
            {
              const string fileAni = (hdf5Dir+"../"+hierStr +varName +extAni);
              ios_base::openmode mode = (step==0 ? ios_base::out
                                         : ios_base::app);
              ofstream animationList(fileAni.c_str(),mode);
              animationList << hierStr << "/" << hd5Filename << endl;
              animationList.close();
            }
        }
    }
  return hdf5Dir;
}


int OutputManager::outputConvergence
(std::ostream& os, const Vector<Vector<Real> >& tsErr,
 const int baseGrid, const int hierRatio,
 const Vector<Real>& targetConvergeRate) const
{
  CH_assert(m_defined);

  const Vector<int> errNT = get(errNormType);
  const std::string sep(" | ");
  Vector<int> width = get(tableColumnWidth);
  const char numC[] = "0123456789";
  const int nHiers = m_numErrors;
  //  CH_assert(tsErr[0].size()>=nHiers);
  int status = 0;
  for (int nt=0; nt<errNT.size(); nt++) {
    os << "\n--------------------------------------------------------\n";
    os << paddedStr(std::string("Grids"), width[0]) << sep
       << paddedStr(std::string("Error ")+numC[errNT[nt]]+"-Norm", width[1])
       << sep << paddedStr(std::string("Convergence"), width[2]);
    int nCells = baseGrid;
    for (int i=0; i<tsErr[nt].size(); i++)
      {
        os << std::endl
           << paddedStr(nCells, width[0])
           << sep << paddedStr(tsErr[nt][i], width[1]) << sep;
        if (i>0)
          {
            const Real rate = log(tsErr[nt][i-1]/tsErr[nt][i])/log(hierRatio);
            // only care about convergence on the two finest grids.
            if (i==nHiers-1 && rate<targetConvergeRate[nt])
              status += 1;
            os << paddedStr(rate, width[2]);
          }
        nCells *= hierRatio;
      }
  }
  os << "\n---------------------------------------------------------\n";
  return status;
}

const string OutputManager::outputLatexTable
(const Vector<Vector<Real> >& tsErr,
 const int baseGrid,
 const int hierRatio) const
{
  CH_assert(m_defined);

  const std::string about = "Solution";
  const int nHiers = tsErr[0].size();
  //  CH_assert(tsErr[0].size()>=nHiers);
  std::ostringstream os;
  os << "\\begin{tabular}{";
  for (int i=0; i<2*nHiers-1;i++)
    os << "c|";
  os << "c}\n\\hline \n";
  os << "Base grid $h$ & ";
  int tmp = baseGrid;
  for (int i=0; i<nHiers-1; i++)
    {
      os << "$1/" << tmp << "$ & Rate & ";
      tmp *= hierRatio;
    }
  os << "$1/" << tmp << "$\n \\\\ \\hline \\hline\n";
  for (int i=0; i<tsErr.size(); i++)
    {
      os << about << " $L_";
      if (i>0)
        os << i << "$";
      else
        os << "{\\infty}" << "$";
      for (int j=0; j<tsErr[i].size(); j++)
        {
          os << " & ";
          os.precision(get(floatPrecision));
          os.setf(std::ios::scientific, std::ios::floatfield);
          //          os << setiosflags(ios::scientific) << setw(8)
          os << tsErr[i][j];
          os.setf(std::ios::fixed, std::ios::floatfield);
          if (j<nHiers-1) {
            os << " & ";
            os << std::setw(get(floatPrecision)+2)
               << log(tsErr[i][j]/tsErr[i][j+1])/log(hierRatio);
          }
        }
      os << "\n \\\\ \\hline\n";
    }
  os << "\\end{tabular}\n";
  return os.str();
}

