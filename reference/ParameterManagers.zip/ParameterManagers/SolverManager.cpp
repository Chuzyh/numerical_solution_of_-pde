#include "SolverManager.H"

#define PM_CLASSNAME SolverManager
#define PM_TEMPLATESTR  
using std::string;

/// table of the default values.
//--------------------------------------------------------------
PM_DEF (   int,                timeOrder,                4);
PM_DEF (   int,               spaceOrder,                4);
PM_DEF (   int,                numGhosts,                2);
PM_DEF (  Real,                      cfl,              1.0);
PM_DEF (  Real,                       t0,              0.0);
PM_DEF (  bool,           useCellAverage,             true);
PM_DEF (string,       pressureExtraction,       "velocity");
PM_DEF (  bool,  correctNeumannBCSum4PPE,            false);
PM_DEF (  bool,  useAdaptiveTimeStepping,            false);
PM_DEF (  bool,      useSubcyclingInTime,            false);
PM_DEF (  bool,               useLimiter,            false);
PM_DEF (   int,              numPreRelax,                4);
PM_DEF (   int,             numPostRelax,                4);
PM_DEF (   int,           numBottomRelax,               10);
PM_DEF (   int,                cycleType,                1);
PM_DEF (   int,             numMaxCycles,               30);
PM_DEF (  Real,            convergeRatio,          1.0e-10);
PM_DEF (  Real,                hangRatio,             -2.0);
PM_DEF (  Real,               normThresh,          1.0e-12);
PM_DEF (  bool,      use2ndOrderSmoother,            false);
PM_DEF (   int,      verbosityHyperbolic,                3);
PM_DEF (   int,        verbosityElliptic,                3);
PM_DEF (   int,    verbosityBottomSolver,                0);
PM_DEF (string,                velBC4Cnv,           "None");
PM_DEF (string,             velBC4DffExp,           "None");
PM_DEF (string,             velBC4DffImp,           "None");
PM_DEF (string,           velBC4CnvInPEV,           "None");
PM_DEF (string,           cnvBC4DivInPEV,           "None");
PM_DEF (string,          velBC4DffInPEEA,           "None");
PM_DEF (string,          cnvBC4DivInPEEA,           "None");
PM_DEF (string,              accBCInPEEA,           "None");
//--------------------------------------------------------------
typedef ParameterDependency<std::string> PDP;
//---------- Existence::False -----
PM_DEFD( int,                numSteps0,         1,
        PDP(PDP::ExistenceFalse, "useAdaptiveTimeStepping"));
//---------- Existence::True ------
PM_DEFD(Real,                       te,       1.0,
        PDP( PDP::ExistenceTrue, "useAdaptiveTimeStepping"));
PM_DEFD(Real,               cflInitial,       0.1,
        PDP( PDP::ExistenceTrue, "useAdaptiveTimeStepping"));
PM_DEFD(Real,              maxDtGrowth,       1.1,
        PDP( PDP::ExistenceTrue, "useAdaptiveTimeStepping"));
PM_DEFD(Real,        dtToleranceFactor,       1.1,
        PDP( PDP::ExistenceTrue, "useAdaptiveTimeStepping"));
///-------------------------------------------------------------


SolverManager::SolverManager() : PPM()
{
  initializeParameters();
}

void SolverManager::initializeParameters(void)
{
  PM_INIT(timeOrder);
  PM_INIT(spaceOrder);
  PM_INIT(numSteps0);
  PM_INIT(numGhosts);
  PM_INIT(cfl);
  PM_INIT(t0);
  PM_INIT(te);
  PM_INIT(useCellAverage);
  PM_INIT(pressureExtraction);
  PM_INIT(useAdaptiveTimeStepping);
  PM_INIT(useSubcyclingInTime);
  PM_INIT(cflInitial);
  PM_INIT(maxDtGrowth);
  PM_INIT(dtToleranceFactor);
  PM_INIT(useLimiter);
  PM_INIT(numPreRelax);
  PM_INIT(numPostRelax);
  PM_INIT(numBottomRelax);
  PM_INIT(cycleType);
  PM_INIT(numMaxCycles);
  PM_INIT(convergeRatio);
  PM_INIT(hangRatio);
  PM_INIT(normThresh);
  PM_INIT(use2ndOrderSmoother);
  PM_INIT(verbosityHyperbolic);
  PM_INIT(verbosityElliptic);
  PM_INIT(verbosityBottomSolver);
  PM_INIT(velBC4Cnv);
  PM_INIT(velBC4DffExp);
  PM_INIT(velBC4DffImp);
  PM_INIT(velBC4CnvInPEV);
  PM_INIT(cnvBC4DivInPEV);
  PM_INIT(velBC4DffInPEEA);
  PM_INIT(cnvBC4DivInPEEA);
  PM_INIT(accBCInPEEA);
  PM_INIT(correctNeumannBCSum4PPE);
}

void SolverManager::updateDependentParameters(void)
{
  // remove ExistenceTrue-dependent parameters
  if ( get(useAdaptiveTimeStepping) )
    {
      erase(numSteps0);
    }
  else
    {
      erase(te);
      erase(cflInitial);
      erase(maxDtGrowth);
      erase(dtToleranceFactor);
    }

  string pressureExtr = get(pressureExtraction);
  if (pressureExtr!=string("EulerianAcceleration")
      && pressureExtr!=string("velocity"))
    MayDay::Error("Unknown pressureExtraction!");
}
