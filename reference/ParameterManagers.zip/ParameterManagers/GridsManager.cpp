#include "GridsManager.H"

#include "BRMeshRefine.H"
#include "BoxIterator.H"
#include "DataIterator.H"
#include "LoadBalance.H"
#include "MayDay.H"
#include "parstream.H"

#define PM_CLASSNAME GridsManager
#define PM_TEMPLATESTR  

/// Table of default values 
//------------------------------------------------------------------
PM_DEF (     RealVect,               origin,  RealVect::Zero);
PM_DEF (     RealVect,                 xHi0,  RealVect::Unit);
PM_DEFC(      IntVect,                 iLo0,   IntVect::Zero);
PM_DEF (      IntVect,            numCells0,   IntVect::Unit);
PM_DEF (          int,            numLevels,               2);
PM_DEF (          int,             refRatio,               2);
PM_DEF (      IntVect,          periodicity,   IntVect::Unit);
PM_DEF (         bool, useAdaptiveRegriding,           false);
PM_DEF (          int,        tagBufferSize,               3);

// dependent parameters
// --------------------------------------------------------------
typedef ParameterDependency<std::string> PDP;
PM_DEFD(         Real,                  dx0,                 1.0,
        PDP(         PDP::Value,                 "xHi0"));
PM_DEFD(ProblemDomain,              domain0,     ProblemDomain(),
        PDP(         PDP::Value,            "numCells0"));
//---------- Existence::False
PM_DEFD(  Vector<int>,        numLevelBoxes,    Vector<int>(8,1),
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xLo1,      RealVect::Zero,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xHi1,      RealVect::Unit,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xLo11,     RealVect::Unit,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xHi11,     RealVect::Zero,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xLo12,     RealVect::Unit,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xHi12,     RealVect::Zero,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xLo13,     RealVect::Unit,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xHi13,     RealVect::Zero,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xLo2,      RealVect::Zero,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xHi2,      RealVect::Unit,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xLo21,     RealVect::Unit,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xHi21,     RealVect::Zero,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xLo22,     RealVect::Unit,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xHi22,     RealVect::Zero,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xLo23,     RealVect::Unit,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
PM_DEFD(     RealVect,                 xHi23,     RealVect::Zero,
        PDP(PDP::ExistenceFalse, "useAdaptiveRegriding"));
//---------- Existence::True ------
PM_DEFD(  Vector<int>,       regridInterval,    Vector<int>(8,1),
        PDP( PDP::ExistenceTrue, "useAdaptiveRegriding"));
PM_DEFD(          int,          blockFactor,                   4,
        PDP( PDP::ExistenceTrue, "useAdaptiveRegriding"));
PM_DEFD(          int,         maxPatchSize,                  64,
        PDP( PDP::ExistenceTrue, "useAdaptiveRegriding"));
PM_DEFD(         Real,            fillRatio,                0.75,
        PDP( PDP::ExistenceTrue, "useAdaptiveRegriding"));
PM_DEFD(  std::string,      taggingCriteria,    "absValueBigger",
        PDP( PDP::ExistenceTrue, "useAdaptiveRegriding"));
PM_DEFD( Vector<Real>,         refineThresh, Vector<Real>(9,0.1),
        PDP( PDP::ExistenceTrue, "useAdaptiveRegriding"));
///----------------------------------------------------------------

GridsManager::GridsManager()
  : ParameterManager9<bool,int,Real,std::string,IntVect,RealVect,
                      Vector<int>,Vector<Real>,ProblemDomain>()
{
  initializeParameters();
}

void GridsManager::initializeParameters(void)
{
  PM_INIT(origin);
  PM_INIT(xHi0);
  PM_INIT(iLo0);
  PM_INIT(numCells0);
  PM_INIT(numLevels);
  PM_INIT(refRatio);
  PM_INIT(useAdaptiveRegriding);
  PM_INIT(numLevelBoxes);
  PM_INIT(xLo1);
  PM_INIT(xHi1);
  PM_INIT(xLo11);
  PM_INIT(xHi11);
  PM_INIT(xLo12);
  PM_INIT(xHi12);
  PM_INIT(xLo13);
  PM_INIT(xHi13);
  PM_INIT(xLo2);
  PM_INIT(xHi2);
  PM_INIT(xLo21);
  PM_INIT(xHi21);
  PM_INIT(xLo22);
  PM_INIT(xHi22);
  PM_INIT(xLo23);
  PM_INIT(xHi23);
  PM_INIT(regridInterval);
  PM_INIT(tagBufferSize);
  PM_INIT(blockFactor);
  PM_INIT(maxPatchSize);
  PM_INIT(fillRatio);
  PM_INIT(taggingCriteria);
  PM_INIT(refineThresh);
  PM_INIT(periodicity);
}

void GridsManager::updateDependentParameters(void)
{
  const RealVect tmp = (get(xHi0)-get(origin))/RealVect(get(numCells0));
  if (tmp!=tmp[0]*RealVect::Unit)
    MayDay::Error("Inconsistency of numCells0 with origin and xHi0!\n");
  set(dx0, tmp[0]);
  const Box box0(get(iLo0), get(iLo0)+get(numCells0)-IntVect::Unit);
  ProblemDomain pdom0(box0);
  for (int i=0; i<SpaceDim; i++)
    pdom0.setPeriodic(i, get(periodicity)[i]);
  set(domain0, pdom0);
  // remove some Existence-dependent parameters from the map
  if ( get(useAdaptiveRegriding) )
    {
      erase(numLevelBoxes);
      erase(xLo1);
      erase(xHi1);
      erase(xLo11);
      erase(xHi11);
      erase(xLo12);
      erase(xHi12);
      erase(xLo13);
      erase(xHi13);
      erase(xLo2);
      erase(xHi2);
      erase(xLo21);
      erase(xHi21);
      erase(xLo22);
      erase(xHi22);
      erase(xLo23);
      erase(xHi23);
    }
  else
    {
      erase(blockFactor);
      erase(maxPatchSize);
      erase(fillRatio);
      erase(taggingCriteria);
      erase(refineThresh);
      erase(regridInterval);
    }
}

int GridsManager::computeSplit(void) const
{
  unsigned int nPs = numProc();
  int split = static_cast<int>(pow(nPs, 1./SpaceDim));
  while ((split*IntVect::Unit).product()<nPs)
    split++;
  return split;
}

int GridsManager::maxComponent(const IntVect& iv)
{
  int maxC = iv[0];
  for (int d=1; d<SpaceDim; d++)
    if (maxC<iv[d])
      maxC = iv[d];
  return maxC;
}


void GridsManager::createMultiGrids(Vector<DBL>& dblV,
                                    const int hierRatio) const
{
  dblV.resize(get(numLevels));
  ProblemDomain dom = refine(get(domain0), hierRatio);
  const int split = this->computeSplit();
  for (int i=0; i<get(numLevels); i++)
    {
      const Box domBox = dom.domainBox();
      Vector<Box> boxes(1,domBox);
      if (split>1)
        {
          const int maxSz = (maxComponent(domBox.size())+1)/split;
          domainSplit(domBox, boxes, maxSz, get(refRatio));
          mortonOrdering(boxes);
        }
      Vector<int> procs;
      LoadBalance(procs, boxes);
      dblV[i] = DisjointBoxLayout(boxes, procs, dom);
      dom.refine(get(refRatio));
    }
}


void GridsManager::createStaticGrids(Vector<DisjointBoxLayout>& dblV,
                                     const int hierRatio,
                                     bool singleLevel) const
{
  const int nLevels = ( singleLevel? 1 : get(numLevels) );
  CH_assert(nLevels>=1 && nLevels<=3);
  dblV.resize(nLevels);
  const int r = get(refRatio);
  const ProblemDomain dmn0 = refine(get(domain0), hierRatio);
  const Box domBox = dmn0.domainBox();
  const int split = this->computeSplit();

  // boxes in Level 0 : just domain
  Vector<Box> boxes(1,domBox), tmpBoxes;
  if (split>1)
    {
      const int maxSz = (maxComponent(domBox.size())+1)/split;
      domainSplit(domBox, boxes, maxSz, r);
      // For a rectangular domBox with large aspect ratio,
      //  the number of sub-boxes in boxes may be less than numProc();
      // ensure that boxes.size() is at least numProc().
      while (boxes.size()<numProc())
        {
          const Vector<Box> tmpBoxes = boxes;
          boxes.resize(0);
          for (int i=0; i<tmpBoxes.size(); i++)
            {
              const Box& tbx = tmpBoxes[i];
              const int maxBxSz = (maxComponent(tbx.size())+1)/split;
              Vector<Box> buffer;
              domainSplit(tbx, buffer, maxBxSz, r);
              boxes.append(buffer);
            }
        }
      mortonOrdering(boxes);
    }
  Vector<int> procs;
  LoadBalance(procs, boxes);
  dblV[0] = DisjointBoxLayout(boxes, procs, dmn0) ;
  pout() << " " << boxes.size() << " Boxes on level 0 : \n "
         << boxes << std::endl;

  const Real h0 = get(dx0)/hierRatio;
  if (nLevels>1)
    {
      boxes.clear();
      const Real h1 = h0/r;
      // assume square domain for a simple nested hierarchy
      Vector<RealVect> xiLo1(4), xiHi1(4);
      xiLo1[0] = (get(xLo1)-get(origin))/h0;
      xiHi1[0] = (get(xHi1)-get(origin))/h0;
      xiLo1[1] = (get(xLo11)-get(origin))/h0;
      xiHi1[1] = (get(xHi11)-get(origin))/h0;
      xiLo1[2] = (get(xLo12)-get(origin))/h0;
      xiHi1[2] = (get(xHi12)-get(origin))/h0;
      xiLo1[3] = (get(xLo13)-get(origin))/h0;
      xiHi1[3] = (get(xHi13)-get(origin))/h0;
      const int nBox1 = get(numLevelBoxes)[1];
      if (nBox1>4)
        CH_assert(!"more than 4 boxes per level is not supported yet!\n");
      for (int i=0; i<nBox1; i++)
        {
          IntVect tmpLo, tmpHi;
          for (int d=0; d<SpaceDim; d++)
            {
              tmpLo[d] = r * static_cast<int>(xiLo1[i][d]);
              tmpHi[d] = r * static_cast<int>(xiHi1[i][d]);
            }
          Box tmp(tmpLo, tmpHi-IntVect::Unit);
          if (!tmp.isEmpty()) // do not bother with a bad box.
            {
              if (split>1)
                {
                  const int maxSz = (maxComponent(tmp.size())+1)/split;
                  domainSplit(tmp, tmpBoxes, maxSz, r);
                }
              else
                {
                  tmpBoxes = Vector<Box>(1,tmp);
                }
              boxes.append(tmpBoxes);
            }
        }
      // Brian told me it is not worthwhile to sweat
      //  assigning fine and coarse boxes to the same processor.
      // calling mortonOrdering is good enough.
      mortonOrdering(boxes);
      LoadBalance(procs, boxes);
      const ProblemDomain dom1 = refine(dmn0, r);
      dblV[1] = DisjointBoxLayout(boxes, procs, dom1);
      pout() << " " << boxes.size() << " Boxes on level 1 : \n "
             << boxes << std::endl;
    }
  // below is an ugly way to duplicate the above algorithm
  if (nLevels>2)
    {
      boxes.clear();
      const Real h1 = h0/r;
      const Real h2 = h0/r/r;
      // assume square domain for a simple nested hierarchy
      Vector<RealVect> xiLo(4), xiHi(4);
      xiLo[0] = (get(xLo2)-get(origin))/h1;
      xiHi[0] = (get(xHi2)-get(origin))/h1;
      xiLo[1] = (get(xLo21)-get(origin))/h1;
      xiHi[1] = (get(xHi21)-get(origin))/h1;
      xiLo[2] = (get(xLo22)-get(origin))/h1;
      xiHi[2] = (get(xHi22)-get(origin))/h1;
      xiLo[3] = (get(xLo23)-get(origin))/h1;
      xiHi[3] = (get(xHi23)-get(origin))/h1;
      const int nBox = get(numLevelBoxes)[2];
      if (nBox>4)
        CH_assert(!"more than 4 boxes per level is not supported yet!\n");

      for (int j=0; j<2; j++)
        {
          const int spltSz = j==0? split : numProc();
          for (int i=0; i<nBox; i++)
            {
              IntVect tmpLo, tmpHi;
              for (int d=0; d<SpaceDim; d++)
                {
                  tmpLo[d] = r * static_cast<int>(xiLo[i][d]);
                  tmpHi[d] = r * static_cast<int>(xiHi[i][d]);
                }
              Box tmp(tmpLo, tmpHi-IntVect::Unit);
              if (!tmp.isEmpty()) // do not bother with a bad box.
                {
                  if (split>1)
                    {
                      const int maxSz = (maxComponent(tmp.size())+1)/spltSz;
                      domainSplit(tmp, tmpBoxes, maxSz, r);
                    }
                  else
                    {
                      tmpBoxes = Vector<Box>(1,tmp);
                    }
                  boxes.append(tmpBoxes);
                }
            }
          if (boxes.size()>=numProc())
            break;
          else
            boxes.clear();
        }
      // Brian told me it is not worthwhile to sweat
      //  assigning fine and coarse boxes to the same processor.
      // calling mortonOrdering is good enough.
      mortonOrdering(boxes);
      LoadBalance(procs, boxes);
      ProblemDomain dom = refine(dmn0, r*r);
      dblV[2] = DisjointBoxLayout(boxes, procs, dom);
      pout() << " " << boxes.size() << " Boxes on level 2 : \n "
             << boxes << std::endl;
    }

  if (nLevels>3)
    CH_assert(!"more than three levels is not supported yet!\n");
}


void GridsManager::createAdaptiveGrids
(Vector<DBL>& dblV, const Vector<LFA*>& taggingData, const int hierRatio,
 const Real ttt) const
{
  CH_assert(get(useAdaptiveRegriding));
  const int nLevels = taggingData.size();
  CH_assert(nLevels==get(numLevels));

  // Create tags based on taggingCriteria
  Vector<IntVectSet> tags(nLevels);
  const string& tgc = get(taggingCriteria);
  if (tgc == string("absValueBigger"))
    {
      for (int i=0; i<nLevels-1; i++)
        {
          const Real thresh = get(refineThresh)[i];
          tags[i].makeEmpty();
          for (DataIterator dit = taggingData[i]->dataIterator();
               dit.ok(); ++dit)
            {
              const Box& b = taggingData[i]->disjointBoxLayout()[dit()];
              const FArrayBox& fab = (*taggingData[i])[dit()];
              for (BoxIterator bit(b); bit.ok(); ++bit)
                if (abs(fab(bit())) >= thresh)
                  tags[i] |= bit();
            }
        }
    }
  else if (tgc == string("valueBigger"))
    {
      for (int i=0; i<nLevels-1; i++)
        {
          const Real thresh = get(refineThresh)[i];
          tags[i].makeEmpty();
          for (DataIterator dit = taggingData[i]->dataIterator();
               dit.ok(); ++dit)
            {
              const Box& b = taggingData[i]->disjointBoxLayout()[dit()];
              const FArrayBox& fab = (*taggingData[i])[dit()];
              for (BoxIterator bit(b); bit.ok(); ++bit)
                if (fab(bit()) >= thresh)
                  tags[i] |= bit();
            }
        }
    }
  else if (tgc == string("valueSmaller"))
    {
      for (int i=0; i<nLevels-1; i++)
        {
          const Real thresh = get(refineThresh)[i];
          tags[i].makeEmpty();
          for (DataIterator dit = taggingData[i]->dataIterator();
               dit.ok(); ++dit)
            {
              const Box& b = taggingData[i]->disjointBoxLayout()[dit()];
              const FArrayBox& fab = (*taggingData[i])[dit()];
              for (BoxIterator bit(b); bit.ok(); ++bit)
                if (fab(bit()) <= thresh)
                  tags[i] |= bit();
            }
        }
    }
  else if (tgc == string("absValueBiggerSVB"))
    {
      const bool timeRange = ttt<3;
      for (int i=0; i<nLevels-1; i++)
        {
          const Real thresh = get(refineThresh)[i];
          tags[i].makeEmpty();
          for (DataIterator dit = taggingData[i]->dataIterator();
               dit.ok(); ++dit)
            {
              const DBL& dbl = taggingData[i]->disjointBoxLayout();
              Box b = dbl.physDomain().domainBox();
              IntVect sz = b.size();
              sz /= 4;
              // b is now the center square of the domain
              b.grow(-sz);
              const FArrayBox& fab = (*taggingData[i])[dit()];
              for (BoxIterator bit(dbl[dit()]); bit.ok(); ++bit)
                {
                  const IntVect cid = bit();
                  bool tag = timeRange;
                  if (!timeRange)
                    tag = !(b.contains(cid));
                  tag &= abs(fab(cid)) >= thresh;
                  if (tag)
                    tags[i] |= bit();
                }
            }
        }
      /// The following approach does not work for the parallel case.
      /// remove center box if this does not lead to an empty level
      // for (int i=1; i<nLevels-1; i++)
      //   {
      //     const DBL& dbl = taggingData[i]->disjointBoxLayout();
      //     Box b = dbl.physDomain().domainBox();
      //     IntVect sz = b.size();
      //     sz /= 4;
      //     // b is now the center square of the domain
      //     b.grow(-sz);
      //     IntVectSet testTags = tags[i];
      //     testTags -= b;
      //     // remove the center box if the resulting tags aren't empty.
      //     if (!testTags.isEmpty())
      //       {
      //         tags[i] -= b;
      //         pout() << "tags after removing the center box: \n" << tags[i];
      //       }
      //   }
    }
  else if (tgc == string("proximityToBdry"))
    {
      for (int i=0; i<nLevels-1; i++)
        { // round the real number to an integer
          const int proximity = static_cast<int>
            (floor(get(refineThresh)[i]+0.5));
          const DBL& dbl = taggingData[i]->disjointBoxLayout();
          const Box& domainBox = dbl.physDomain().domainBox();
          const Box shrunkBox = grow(domainBox, -abs(proximity));
          tags[i].makeEmpty();
          for (DataIterator dit = taggingData[i]->dataIterator();
               dit.ok(); ++dit)
            {
              const Box& b = dbl[dit()];
              for (BoxIterator bit(b); bit.ok(); ++bit)
                if (!shrunkBox.contains(bit()))
                  tags[i] |= bit();
            }
        }
    }
  else if (tgc == string("proximityToCrns"))
    {
      for (int i=0; i<nLevels-1; i++)
        { // round the real number to an integer
          const int proximity = static_cast<int>
            (floor(get(refineThresh)[i]+0.5));
          // initialize tags to domain box.
          const DBL& dbl = taggingData[i]->disjointBoxLayout();
          const Box& domainBox = dbl.physDomain().domainBox();
          tags[i].makeEmpty();
          tags[i] |= domainBox;
          // cut to corners
          const Box testBox = grow(domainBox, -proximity*IntVect::Unit);
          for (int d=0; d<SpaceDim; d++)
            tags[i] -= grow(testBox, proximity*BASISV(d));

          for (DataIterator dit = taggingData[i]->dataIterator();
               dit.ok(); ++dit)
            tags[i] &= dbl[dit()];
        }
    }
  else
    {
      string errMsg("unrecognized taggingCriteria: ");
      errMsg += get(taggingCriteria);
      MayDay::Error(errMsg.c_str());
    }

  for (int i=0; i<nLevels-1; i++)
    if (tags[i].isEmpty())
      pout() << " WARNING: The " << i+1 << "-th level is empty!\n";

  ProblemDomain dom0 = refine(get(domain0), hierRatio);
  // define a BRMeshrefine and use it to do the job
  BRMeshRefine meshRefine(dom0,
                          Vector<int>(get(numLevels), get(refRatio)),
                          get(fillRatio),
                          get(blockFactor),
                          get(tagBufferSize),
                          get(maxPatchSize));
  Vector<Vector<Box> > boxes;
  Vector<Vector<Box> > domBoxes(nLevels);
  domBoxes[0] = Vector<Box>(1, dom0.domainBox());
  for (int i=1; i<nLevels; i++)
    domBoxes[i] = Vector<Box>(1, refine(domBoxes[i-1][0], get(refRatio)));
  meshRefine.regrid(boxes, tags, 0, nLevels-1, domBoxes);

  // put boxes into DBL
  //  here the size of boxes is used because some fine levels might be absent

  // note by Zhixuan Li
  // VariableManager requires dbl.size() == numLevels, 
  // and HOP works well with absent levels.

  boxes.resize(nLevels);
  dblV.resize(nLevels);
  const bool outputBoxes = true;
  for (int i=0; i<nLevels; i++)
    {
      mortonOrdering(boxes[i]);
      Vector<int> procs;
      LoadBalance(procs, boxes[i]);
      dblV[i] = DisjointBoxLayout(boxes[i], procs, dom0);
      dom0.refine(get(refRatio));
      if (outputBoxes)
        pout() << " " << boxes[i].size() << " Boxes on level "
               << i <<" : \n " << boxes[i] << std::endl;
    }

}
