#include "Variable.H"


#define PM_CLASSNAME Variable
#define PM_TEMPLATESTR  

/// table of the default values.
//-----------------------------------------------------------
PM_DEF(std::string,        name,           "invalid");
PM_DEF(        int,   numGhosts,                   0);
PM_DEF(        int,    numComps,                   1);
PM_DEF(        int,   centering,  Variable::CellAvgd);
///----------------------------------------------------------

static const char numStr[] = "0123456789";


Variable::Variable() : PMM()
{
  initializeParameters();
}

void Variable::initializeParameters(void)
{
  PM_INIT(name);
  PM_INIT(numGhosts);
  PM_INIT(numComps);
  PM_INIT(centering);
}

Variable::Variable(char const*const a_name,
                   const int a_numGhosts,
                   const int a_numComps,
                   const CENTERING a_centering) : PMM()
{
  set(name, a_name);
  set(numGhosts, a_numGhosts);
  set(numComps, a_numComps);
  set(centering, a_centering);
}

const std::string Variable::getComponentName(int comp) const
{
  CH_assert(comp<10);
  std::string compName = get(name);
  if (get(numComps)>1)
    compName += std::string("-")+numStr[comp];
  return compName;
}


bool operator<(const Variable& v1, const Variable& v2)
{
  /// there should be no variables with the same name but different layout.
  if (v1.get(Variable::name)==v2.get(Variable::name))
    {
      CH_assert(v1.get(Variable::numGhosts)==v2.get(Variable::numGhosts));
      CH_assert(v1.get(Variable::numComps) ==v2.get(Variable::numComps) );
      CH_assert(v1.get(Variable::centering)==v2.get(Variable::centering));
      return false;
    }
  return (v1.get(Variable::name) < v2.get(Variable::name));
}
