#include "ParameterManagerHelpers.H"

template<>
int setPMapFrom<RealVect>(ParameterManager<RealVect>::MAP& pmap,
                          const ParmParse& pp)
{
  int count = 0;
  std::vector<Real> tmp;
  for (ParameterManager<RealVect>::MAP::iterator mit = pmap.begin();
       mit != pmap.end(); mit++)
    {
      // do not import dependent parameters
//       if (mit->first.dependency() != Parameter<RealVect>::Dependency::None)
//         continue;
      char const*const key = mit->first.key();
      const int nVal = pp.countval(key);
      if (nVal>0)
        {
          pp.getarr(key, tmp, 0, nVal);
          mit->second = RealVect(tmp);
          count++;
        }
    }
  return count;
}

template<>
int setPMapFrom<IntVect>(ParameterManager<IntVect>::MAP& pmap,
                         const ParmParse& pp)
{
  int count = 0;
  std::vector<int> tmp;
  for (ParameterManager<IntVect>::MAP::iterator mit = pmap.begin();
       mit != pmap.end(); mit++)
    {
      // do not import dependent parameters
//       if (mit->first.dependency() != Parameter<IntVect>::Dependency::None)
//         continue;
      char const*const key = mit->first.key();
      const int nVal = pp.countval(key);
      if (nVal>0)
        {
          pp.getarr(key, tmp, 0, nVal);
          mit->second = IntVect(tmp);
          count++;
        }
    }
  return count;
}

template<>
int setPMapFrom<ProblemDomain>(ParameterManager<ProblemDomain>::MAP& pmap,
                               const ParmParse& pp)
{
  return 0;
}

